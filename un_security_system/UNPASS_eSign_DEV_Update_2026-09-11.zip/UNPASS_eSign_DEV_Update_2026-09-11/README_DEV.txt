UNPASS eSign DEV UPDATE — 11 September 2026
===========================================

Use this package in your DEVELOPMENT environment.

Fixes included
--------------
- Default saved signature automatically selected on the signing page.
- Completed workflow-form PDF shows Completed instead of frozen In progress.
- One stable Envelope ID is displayed on the workflow form.
- Later internal signature-envelope IDs remain in the audit trail without stacking.
- `_runtime_state` renamed to `runtime_state` for Django template safety.

Install
-------
Copy these files to your local repository root:

    apply_dev_update.py
    verify_dev_update.py

Then run:

    python apply_dev_update.py
    python manage.py check
    python verify_dev_update.py

A backup is created automatically:
    _dev_esign_backup_YYYYMMDD-HHMMSS/

Files modified
--------------
un_security_system/accounts/workflow_engine_esign.py
un_security_system/accounts/form_logic_esign.py
un_security_system/templates/accounts/esign/sign.html
un_security_system/templates/accounts/esign/studio/_form_sheet.html

No database migration is required.
