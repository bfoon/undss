UNPASS eSign — FULL COPY / SELF-APPLY UPDATE
============================================

This version is for copy-and-paste deployment. You do NOT manually merge the
old snippets.

HOW TO APPLY
------------
1. Extract the ZIP on your computer.
2. Copy the entire folder contents (`apply_full_update.py`, `payload`,
   `patch_data`) to the ROOT of your UNPASS repository — the same directory
   that contains `un_security_system`.
3. Run:

       python3 apply_full_update.py

4. The installer automatically creates:

       _esign_upgrade_backup_YYYYMMDD-HHMMSS/

   containing the original version of every existing file it changes.

5. Check Django:

       docker compose -f docker-compose.prod.yml exec web python manage.py check

   or, outside Docker:

       python manage.py check

6. Restart/rebuild using your normal UNPASS deployment procedure.

NO DATABASE MIGRATION IS REQUIRED.

INCLUDED
--------
- Form workflow signature steps no longer generate extra signature pages.
- Missing form signature spaces block the step with a clear configuration error.
- Workflow child envelope IDs no longer write repeatedly over the document.
- Signature images are centred, scaled and clipped inside the intended signature box.
- eSign text values are clipped inside their boxes.
- Advanced workflow conditions: AND / OR / NOT, many operators and field-to-field backend.
- Flow export/import using `.unpassflow` packages.
- Word `.docx` -> editable UNPASS form import.
- Grey/read-only sections and "Already filled" presentation.
- Owner-configurable conditional state for fields.
- Per-field label/value font size, field height, padding, background and border.
- Optional free positioning with 20 px snap-to-grid.
- Free-position coordinates are also used for PDF placement.
- Existing old grid forms remain compatible.

IMPORTANT TESTS AFTER INSTALL
-----------------------------
1. Normal standalone envelope:
   Confirm its Envelope ID still prints normally.

2. Form workflow with two signature rounds:
   Confirm the original form page count remains unchanged and signatures appear
   in the designed signature spaces.

3. Existing old form:
   Confirm it still renders with the normal 12-column layout.

4. New form:
   Turn on "Free position with snap-to-grid", drag/resize a field and preview
   the PDF.

5. Workflow condition:
   Add two conditions with AND/OR and test both Yes and No paths.

6. Export/import:
   Export a flow, import it as a new flow, then remap the assignees.

7. Word import:
   Import a DOCX and review the detected fields before publishing.
